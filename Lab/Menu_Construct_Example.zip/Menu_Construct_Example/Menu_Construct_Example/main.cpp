/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on March 15, 2018, 10:41 AM
 * Purpose: Menu with construct examples
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here


//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    char choice;
    
    cout<<"Choose from the following menu. \n"
            "Type 1 for independent if example"<<endl;
    cout<<"type 2 for the dependent if example"<<endl;
    cout<<"type 3 for the ternary example"<<endl;        
    cout<<"type 4 for the Switch case example"<<endl;   
    cin>>choice;
    //Input or initialize values Here
    if (choice>='1' && choice<='4'){
        switch(choice){
            case '1':{
                cout<<"independent if ex."<<endl;
                 //declare variables
            float hrsWrkd, payRate, payChk;
            //initialize variables 
            cout<<"This program calculates your paycheck"<<endl;
            cout<<"Input the hours worked this week"<<endl;
            cout<<"And your payrate $'s/hour"<<endl;
            cin>>hrsWrkd>>payRate;
            //calculate your pay check
            payChk=hrsWrkd*payRate;
            //if you worked overtime > 40 hours
            if(hrsWrkd>40)payChk+=((hrsWrkd-40)*payRate);
            //output all conditions
            cout<<"Hours Worked = "<<hrsWrkd<<endl;
            cout<<"Pay Rate = $ "<<payRate<<"/hr"<<endl;
                break;
            }
           
             case '2':{
                cout<<"dependent if ex."<<endl;
            //declare variables
            float hrsWrkd, payRate, payChk;
            //initialize variables 
            cout<<"This program calculates your paycheck"<<endl;
            cout<<"Input the hours worked this week"<<endl;
            cout<<"And your payrate $'s/hour"<<endl;
            cin>>hrsWrkd>>payRate;
            //calculate your pay check
            payChk=hrsWrkd*payRate;
            //if you worked overtime > 40 hours
            if(hrsWrkd>=0&&hrsWrkd<=40){
                payChk=hrsWrkd*payRate;
            }
            else{
                payChk+=((hrsWrkd-40)*payRate
            }
            //output all conditions
            cout<<"Hours Worked = "<<hrsWrkd<<endl;
            cout<<"Pay Rate = $ "<<payRate<<"/hr"<<endl;
                break;
            }
              case '3':{
                cout<<"Ternary ex."<<endl;
                 //declare variables
            float hrsWrkd, payRate, payChk;
            //initialize variables 
            cout<<"This program calculates your paycheck"<<endl;
            cout<<"Input the hours worked this week"<<endl;
            cout<<"And your payrate $'s/hour"<<endl;
            cin>>hrsWrkd>>payRate;
            //calculate your pay check
            payChk=(hrsWrkd>=0&&hrsWrkd<=40)?
                hrsWrkd*payRate:
                hrsWrkd*payRate+(hrsWrkd-40)*payRate;
            //if you worked overtime > 40 hours
            if(hrsWrkd>40)payChk+=((hrsWrkd-40)*payRate);
            //output all conditions
            cout<<"Hours Worked = "<<hrsWrkd<<endl;
            cout<<"Pay Rate = $ "<<payRate<<"/hr"<<endl;
                break;
            }
               case '4':{
                cout<<"switch case ex."<<endl;
                 //declare variables
            float hrsWrkd, payRate, payChk;
            //initialize variables 
            cout<<"This program calculates your paycheck"<<endl;
            cout<<"Input the hours worked this week"<<endl;
            cout<<"And your payrate $'s/hour"<<endl;
            cin>>hrsWrkd>>payRate;
            //calculate your pay check
            switch(hrsWrkd>=0&&hrsWrkd<=40){
                case true:{
                    payChk=hrsWrkd*payRate;
                    break;
                }
                default:{
                    payChk=hrsWrkd*payRate;
                }
            }
            //if you worked overtime > 40 hours
            if(hrsWrkd>40)payChk+=((hrsWrkd-40)*payRate);
            //output all conditions
            cout<<"Hours Worked = "<<hrsWrkd<<endl;
            cout<<"Pay Rate = $ "<<payRate<<"/hr"<<endl;
                break;
            }
        }
    }else{
        cout<<"Exiting menu"<<endl;
    }
    //Process/Calculations Here

    //Output Located Here
  
    //Exit
    return 0;
}
 
