
/* 
 * File:   main.cpp
 * Author: Lopez, Michelangelo
 * Created on February 20, 2018, 11:30 AM
 * Purpose: Find the Percentage Increase of US debt
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries 

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Colum 
const float BLLN=1.0e12f; //trillion
const float MILLIN=1.0e06f; //billion
const int PRCNT=100;      //Conversion to percent


//Function Prototypes 

//Execution Begins Here!

int main(int argc, char** argv) {
        //Declare Variables 
    float debtEig, debtNow, usEig, usNow, pcntIn;
        //Initial Variables
    debtEig=9.9*BLLN;
    debtNow=20.7*BLLN;
    usEig=304*MILLIN;
    usNow=326*MILLIN;        
        //Map/Process Inputs to Outputs
    pcntIn=(debtNow-debtEig)/debtEig*PRCNT;
        //Display Outputs
    cout<<"Federal Debt in 2008 = $"<<debtEig/BLLN<<" Trillion"<<endl;
    cout<<"US Pop. in 2008  = "<<usEig/MILLIN<<" Million"<<endl; 
    cout<<"Federal Debt in 2018 $= "<<debtNow/BLLN<<" Trillion"<<endl;
    cout<<"US Pop. in 2018 = "<<usNow/MILLIN<<" Million"<<endl;
    cout<<"Debt per person in 2008 = $"<<debtEig/usEig<<""<<endl; 
    cout<<"Debt per person in 2018 = $"<<debtNow/usNow<<""<<endl;
    cout<<"Percentage Increase from 2008 to 2018 = "<<pcntIn<<"%"<<endl;
        //Exit program

    return 0;
}

