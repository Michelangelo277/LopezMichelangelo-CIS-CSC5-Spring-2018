
/* 
 * File:   main.cpp
 * Author: Lopez, Michelangelo
 * Created on February 22, 2018, 9:30 AM
 * Purpose:finding the distance between objects in space and time to reach them 
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries 

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Colums
const float escpVel=16.6;
const float TRLLN=1e12;
const float lghtSpd=3.0e5;
const float timeCon=3.15e7;
//Function Prototypes 

//Execution Begins Here!

int main(int argc, char** argv) 
{
        //Declare Variables 
    float time, dstnce, years;
        //prompt for the variable value
    
        //Initial Variables
        cout<<"Input the light years it takes to reach your "
            "desired destination."<<endl;
    cin>>time;//time in light years
        //Map/Process Inputs to Outputs
    dstnce=lghtSpd*time*timeCon;
    years=(lghtSpd)/(escpVel)*(time);
        //Display Outputs

    cout<<"This is the distance between the earth and your destination "
            <<dstnce<<"km"<<endl;
    cout<<"This is the time it will take considering exit velocity "<<years<<"Years"<<endl;
    
    
        //Exit program

    return 0;
}

