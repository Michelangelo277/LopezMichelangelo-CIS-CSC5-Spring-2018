/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on May 8, 2018, 11:25 AM
 * Purpose:  Retirement with arrays 
 */

//System Libraries Here
#include <iostream>//I/O Library
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    //Salary in $'s per year, Return on Investment in terms of percent, 
    //Savings required in dollars, percentage deposit in % 
    float salary, roi, savReq, percDep;//Initial Conditions to the program
    //Number of years, Savings at the beginning of the year
    //Interest Earned at the end of the year
    const int NYRS=100;//Size of the array 
    int nYears=50;//Number of years the array is used 
    float svBegYr[NYRS], inEndYr[NYRS],dpEndYr[NYRS];
    int year[NYRS];
    
    //Input or initialize values Here
    salary=1.e5f;//$100,000
    roi=5e-2;   //5%
    savReq=salary/roi;
    percDep=1e-1f;//10%
    nYears=50;    //50 Years
    svBegYr[0]=0;    //No savings at the start in $'s
    inEndYr[0]=0;    //No interest at the beginning
    dpEndYr[0]=salary*percDep;    //Deposit at the end of every year
    //Process/Calculations Here
    year[0]=2021;
    int nYear;
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Year  Year     Savings  Interest  Deposit"<<endl;
    for(int nYear=0;nYear<=nYears&&savReq>svBegYr[nYear];nYear++){
        cout<<setw(2)<<nYear
                <<setw(8)<<year[nYear]
                <<setw(12)<<svBegYr[nYear]
                <<setw(10)<<inEndYr[nYear]
                <<setw(10)<<dpEndYr[nYear]<<endl;
        int isvBgYr=(svBegYr[nYear]+inEndYr[nYear]+dpEndYr[nYear])*100;//Calculates in Pennies
        year[nYear+1]=year[nYear]+1;
        svBegYr[nYear+1]=isvBgYr/100;//Shifts back to dollars
        dpEndYr[nYear+1]=dpEndYr[nYear];
        inEndYr[nYear+1]=svBegYr[nYear+1]*roi;
    }
    
    //Output the last year
    cout<<endl<<"Savings to retire = $"<<svBegYr[nYear]<<" in year "<<year[nYear]<<endl;

    //Exit
    return 0;
}

