/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on March, 20th 2018, 12:15 AM
 * Purpose:  Green Crud Fibonacci
 */

//System Libraries Here
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare all Variables Here
    char p1,p2;
    //Input or initialize values Here
    cout<<"Rock Paper Scissors Game"<<endl;
    p1=rand()%3+'R';
    p1=p1>'S'?'P':p1;
    
    p2=rand()%3+'R';
    p2=p2>'S'?'P':p2;
    //Output Located Here
    cout<<"Player 1 = "<<p1<<endl;
    cout<<"Player 2 = "<<p2<<endl;
    
    //determine the winner
    if(p1==p2){
        cout<<"The game is a tie."<<endl;
    }else if(p1=='P'){
        if(p2=='S'){
            cout<<"Player 2 Wins"<<endl;
        }else{
             cout<<"Player 1 Wins"<<endl;
        }
    }else if(p1=='S'){
        if(p2=='R'){
            cout<<"Player 2 Wins"<<endl;
        }else{
             cout<<"Player 1 Wins"<<endl;
        }
    }else {
        if(p2=='P'){
            cout<<"Player 2 Wins"<<endl;
        }else{
             cout<<"Player 1 Wins"<<endl;
        }
    }
    //Exit
    return 0;
}

