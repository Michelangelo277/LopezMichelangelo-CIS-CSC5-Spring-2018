/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on March, 20th 2018, 11:48 AM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cmath>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number c
    
    //Declare all Variables Here
    int fn,fnm1, fnm2;
    
    //Input or initialize values Here
    
    fnm2=1;
    fnm1=1;
    
    //printout the first 2 in the sequence 
    cout<<"Fibonacci Sequence"<<endl;
    cout<<"{"<<fnm2<<","<<fnm1;
    
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    cout<<","<<fn;
    //calculate the 3rd element in the sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    cout<<","<<fn;
      //calculate the 4th element in the sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    cout<<","<<fn; 
    
    //calculate the 5th element in the sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    cout<<","<<fn;  
    
    //calculate the 6th element in the sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    cout<<","<<fn;
    
    //calculate the 7th element in the sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    cout<<","<<fn;
    
    //calculate the 8th element in the sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    cout<<","<<fn<<"}"<<endl;
    
    //calculate the 9th element in the sequence
    //fn=fnm1+fnm2;
    //fnm2=fnm1;
    //fnm1=fn;
    //cout<<","<<fn<<"}"<<endl;
    //Process/Calculations Here
  
    //Output Located Here
    
    //Exit
    return 0;
}

