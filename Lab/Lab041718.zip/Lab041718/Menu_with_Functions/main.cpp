/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on April 17th, 2018, 10:20 AM
 * Purpose:  Menu using Functions and Examples
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions
const float GRAVITY=6.673e-8f;//cm^3/g/sec^2
const float CMMTRS=0.01f;//cm to meters
const float MTRSFT=3.281f;//Meters to Feet
const float LBSLUG=32.174f;//Pounds per slug

//Function Prototypes
void menu();
void prblm1();
void prblm2();
void prblm3();
void prblm4();
void prblm5();
void prblm6();
void prblm7();
void prblm8();
void prblm9();

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    char choice;
    
    //Loop and Display menu
    do{
        menu();
        cin>>choice;

        //Process/Map inputs to outputs
        switch(choice){
            case '1':{prblm1();break;}
            case '2':{prblm2();break;}
            case '3':{prblm3();break;}
            case '4':{prblm4();break;}
            case '5':{prblm5();break;}
            case '6':{prblm6();break;}
            case '7':{prblm7();break;}
            case '8':{prblm8();break;}
            case '9':{prblm9();break;}
            
            default: cout<<"Exiting Menu"<<endl;
        }
    }while(choice>='1'&&choice<='9');
    
    //Exit stage right!
    return 0;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Menu
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void menu(){
    //Display menu
    cout<<endl<<"Choose from the following Menu"<<endl;
    cout<<"Choose the project you want to view."<<endl;
    cout<<"type 1 for the first project"<<endl;
    cout<<"type 2 for the second project"<<endl;
    cout<<"type 3 for the third project"<<endl;       
    cout<<"type 4 for the forth project"<<endl;
    cout<<"type 5 for the fifth project"<<endl;
    cout<<"type 6 for the sixth project"<<endl;       
    cout<<"type 7 for the seventh project"<<endl;  
    cout<<"type 8 for the eighth project"<<endl;
    cout<<"type 9 for the ninth project"<<endl<<endl; 
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 1
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm1(){
    int month, numYrs, rnFll, totRain;
    //Input or initialize values Here
    cout<<"Input the number of years"<<endl;
    cin>>numYrs;
    //Process/Calculations Here
    for(int years=1;years<=numYrs;years++){
        month=numYrs*12;
        for(int months=1;months<=12;months++){
            cout<<"Input the rainfall for month "<<months<<" of Year "<<years<<endl;
            cin>>rnFll;
            totRain+=rnFll;
        }
    }
    month=numYrs*12;
    //Output Located Here
    cout<<"The average rainfall is "<<totRain/month<<endl;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 2
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm2(){
    //Declare all Variables Here
    float myMass, msEarth, rEarth, myWt, myWtCnv;
    //Input or initialize values Here
    myMass=6;//Slugs*conversion
    myWtCnv=myMass*LBSLUG;
    msEarth=5.972e27f;//grams
    rEarth=6.371e6f;//Meters
    //Process/Calculations Here
    myWt=GRAVITY*CMMTRS*CMMTRS*CMMTRS*myMass*msEarth*MTRSFT/(rEarth*rEarth);
    //Output Located Here
    cout<<fixed<<setprecision(0);
    cout<<myMass<<" slugs = "<<myWt<<" lbs"<<endl;   
    cout<<myMass<<" slugs = "<<myWtCnv<<" lbs"<<endl;     
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 3
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm3(){
    //Declare all Variables Here
    int budget,expAmnt,cost,totExp;
    string expense;
    //Input or initialize values Here
    cout<<"Input your budget for the month"<<endl;
    cin>>budget;
    cout<<"Input the amount of expenses you have for the month"<<endl;
    cin>>expAmnt;
    //Process/Calculations Here
    for(int expns=1;expns<=expAmnt;expns++){
        cout<<"Input an expense"<<endl;        
        cin>>expense;
        cout<<"Input the amount you pay for this Expense"<<endl;
        cin>>cost;
        cout<<"Expense: "<<expense<<" Cost = $"<<cost<<endl;
        totExp+=cost;
        }
    //Output Located Here
    if(totExp>budget){
        cout<<"You are over budget"<<endl;
    }else if(totExp<budget){
        cout<<"You are under budget"<<endl;
    }else{
        cout<<"You have no money"<<endl;
    }     
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 4
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm4(){
    //Declare all Variables Here
    int play, num;
    //Input or initialize values Here
    //Process/Calculations Here
    do{
        cout<<"Guess a number between 1-10"<<endl;
        cin>>play;
        num=rand()%10+1;
        if(num>play){
            cout<<"Number is too low. Try again."<<endl;
        }else if(num<play){
            cout<<"Number is too high"<<endl;
        }    
    }while(num!=play);
    cout<<"You win! :D"<<endl;

}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 1
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm5(){
    //Declare all Variables Here
    int play, num, plyCnt;
    //Input or initialize values Here
    //Process/Calculations Here
    do{
        cout<<"Guess a number between 1-10"<<endl;
        cin>>play;
        num=rand()%10+1;
        if(num>play){
            cout<<"Number is too low. Try again."<<endl;
        }else if(num<play){
            cout<<"Number is too high"<<endl;
        }
        plyCnt+=1;
    }while(num!=play);
    cout<<"You win! :D"<<endl;
    cout<<"Attempts: "<<plyCnt<<endl;
    
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 2
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm6(){
    //Declare all Variables Here
    float seaLvl;
    //Input or initialize values Here
    seaLvl=0;      
    //Process/Calculations Here
    for(int years=1;years<=25;years++){
        seaLvl+=1.5f;
        cout<<"Sea Level in Year "<<years<<":   "<<seaLvl<<" Millimeters"<<endl;
    }
                
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 3
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm7(){
    //Declare all Variables Here
    float memFee=2500,//Dollars paid per year
    prIncr=0.04;//Percent Increase per year
    //Input or initialize values Here
    //Process/Calculations Here
    for(int years=1;years<=6;years++){
        memFee=(memFee*prIncr)+memFee;
        cout<<"Membership Price to Country Club in "<<years<<":   $"<<memFee<<endl;
        }
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 4
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm8(){
    //Declare all Variables Here
    int dstnce, timeTr, speed;
    //Input or initialize values Here
    cout<<"Input the speed of your vehicle in MPH."<<endl;
    cin>>speed;//Miles Per Hour
    cout<<"Input the time you traveled in hours."<<endl;
    cin>>timeTr;
    cout<<"Time Traveled        Speed of Vehicle      Distance Traveled"<<endl;
    cout<<"____________________________________________________________"<<endl;
    //Process/Calculations Here
    for(int time=1;time<=timeTr;time++){
        dstnce=time*speed;
        cout<<time<<" hours             "<<speed<<" "
                "Miles Per Hour            "<<dstnce<<" Miles"<<endl;
    }
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 4
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm9(){
    //Declare all Variables Here
    unsigned int totPay, pyPrDay;//Pennies of Pay
    char numDays=31;//Most number of days in a month
    //Input or initialize values Here
    pyPrDay=1;//Penny on first day
    totPay=pyPrDay;//Total Amount
    //Process/Calculations Here
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Day       Per           Total"<<endl;
    for(int day=1;day<=numDays;day++){
        cout<<setw(2)<<day
                <<setw(12)<<pyPrDay/100.0f
                <<setw(14)<<totPay/100.0f<<endl;
        pyPrDay*=2;
        totPay+=pyPrDay;
                }
}
