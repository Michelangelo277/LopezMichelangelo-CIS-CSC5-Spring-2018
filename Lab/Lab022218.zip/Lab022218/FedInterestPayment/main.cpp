
/* 
 * File:   main.cpp
 * Author: Lopez, Michelangelo
 * Created on February 22, 2018, 11:35 AM
 * Purpose: Calculating The Percentage Interest Payment
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries 

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Colum 
const float TRLLN=1.0e12f; //trillion 10^12
const float BILLN=1.0e9f;//Billion
const int PRCNT=100;      //Conversion to percent


//Function Prototypes 

//Execution Begins Here!

int main(int argc, char** argv) {
        //Declare Variables 
    float fedDebt,//federal debt in dollars
          fedBdgt,//federal budget in dollars
          intRate,//Interest rate on the debt per year 
          dbtPmnt,//debt payment in dollars/year 
          pctPymt;//percentage of payment per year of the federal budget
            
        //Initial Variables
    fedDebt=20.7*TRLLN;
    fedBdgt=4.1*TRLLN;
    
    //input the potential interest rate per year
    cout<<"The program calculates the impact of interest rate "
            "on the Federal Budget given the current Federal Debt"<<endl;
    cout<<"Input the potential interest rate 1 to 5 percent/year"<<endl;
    cin>>intRate;
    
          
        //Map/Process Inputs to Outputs
    intRate=intRate/PRCNT;
    dbtPmnt=fedDebt*intRate;
    pctPymt=dbtPmnt/fedBdgt*PRCNT;
    
        //Display Outputs
    cout<<"Federal Debt                          = $"<<fedDebt/TRLLN<<" Trillion"<<endl;
    cout<<"Federal Budget                        = $"<<fedBdgt/TRLLN<<" Trillion"<<endl;
    cout<<"Interest Rate/Year                    = "<<intRate*PRCNT<<"%"<<endl;
    cout<<"Debt Payment                          ="<<dbtPmnt/BILLN<<" Billion/Year"<<endl;
    cout<<"Percent payment to the federal budget = "<<pctPymt<<"%"<<endl; 
        //Exit program

    return 0;
}

