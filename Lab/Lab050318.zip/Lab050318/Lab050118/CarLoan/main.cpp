/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on May 3, 2018, 10:40 AM
 * Purpose:  Retirement 
 */

//System Libraries Here
#include <iostream>//I/O Library
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    //Salary in $'s per year, Return on Investment in terms of percent, 
    //Savings required in dollars, percentage deposit in % 
    float price, downPay, taxRate, carReg, amntFin, intRate, mnPymnt, bllnPy, totCost;//Initial Conditions to the program
    //Number of years, Savings at the beginning of the year
    //Interest Earned at the end of the year
    price=4e4f;
    downPay=1e-2;
    //Input or initialize values Here
    
    amntFin=price-price*downPay+price*taxRate+price*carReg;
    //Process/Calculations Here
    
    //Output Located Here
    

    //Exit
    return 0;
}

