/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on May 3, 2018, 10:40 AM
 * Purpose:  Retirement 
 */

//System Libraries Here
#include <iostream>//I/O Library
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    //Salary in $'s per year, Return on Investment in terms of percent, 
    //Savings required in dollars, percentage deposit in % 
    float salary, roi, savReq, percDep;//Initial Conditions to the program
    //Number of years, Savings at the beginning of the year
    //Interest Earned at the end of the year
    int nYears;
    float svBegYr, inEndYr,dpEndYr;
    //Input or initialize values Here
    salary=1.e5f;//$100,000
    roi=5e-2;   //5%
    savReq=salary/roi;
    percDep=1e-1f;//10%
    nYears=50;    //50 Years
    svBegYr=0;    //No savings at the start in $'s
    inEndYr=0;    //No interest at the beginning
    dpEndYr=salary*percDep;    //Deposit at the end of every year
    //Process/Calculations Here
    int year=2021;
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Year  Year     Savings  Interest  Deposit"<<endl;
    for(int nYear=0;nYear<=nYears&&savReq>svBegYr;nYear++,year++){
        cout<<setw(2)<<nYear
                <<setw(8)<<year
                <<setw(12)<<svBegYr
                <<setw(10)<<inEndYr
                <<setw(10)<<dpEndYr<<endl;
        int isvBgYr=(svBegYr+inEndYr+dpEndYr)*100;//Calculates in Pennies
        svBegYr=isvBgYr/100;//Shifts back to dollars
        inEndYr=svBegYr*roi;
    }
    cout<<endl<<"Savings to retire = $"<<svBegYr<<" in year "<<year<<endl;
    //Output Located Here
    

    //Exit
    return 0;
}

