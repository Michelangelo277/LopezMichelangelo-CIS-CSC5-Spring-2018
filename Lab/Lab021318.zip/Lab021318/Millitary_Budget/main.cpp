
/* 
 * File:   main.cpp
 * Author: Paul, Michelangelo
 * Created on February 13, 2018, 11:27 AM
 * purpose: Your first program,
 *          Hello World as exsplained in the Kerninghan & Ritchie programming in c
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries 

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Colum
const float TRILLN=1.0e12f; //trillion
const float BLLN=1.0e09f; //billion
const int PRCNT=100;      //Conversion to percent


//Function Prototypes 

//Execution Begins Here!

int main(int argc, char** argv) {
        //Declare Variables 
    float milBdgt, fedBdgt, pcntMil;
        //Initial Variables
    milBdgt=639*BLLN;
    fedBdgt=4.1*TRLLN;
        //Map/Process Inputs to Outputs
    pcntMil=milBdgt/fedBdgt*PRCNT;
        //Display Outputs
    cout<<"Military Budget = $"<<milBdgt/BLLN<<" Billion"<<endl;
    cout<<"Federal Budget = $"<<fedBdgt/TRLLN<<"trillion"<endl; 
    cout<<"Military Percentage = "<<pcntMil<<"%"<<endl;
        
        //Exit program

    return 0;
}

