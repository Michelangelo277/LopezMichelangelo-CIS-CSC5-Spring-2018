
/* 
 * File:   main.cpp
 * Author: Paul, Michelangelo
 * Created on February 13, 2018, 11:27 AM
 * purpose: Your first program,
 *          Hello World as exsplained in the Kerninghan & Ritchie programming in c
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries 

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Colum

//Function Prototypes 

//Execution Begins Here!

int main(int argc, char** argv) {
        //Declare Variables 
    
        //Initial Variables
    
        //Map/Process Inputs to Outputs
    
        //Display Outputs
        cout<<"Hello World"<<endl;
        //Exit program

    return 0;
}

