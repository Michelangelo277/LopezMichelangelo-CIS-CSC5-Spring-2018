
/* 
 * File:   main.cpp
 * Author: Paul, Michelangelo
 * Created on February 13, 2018, 12:06 pm
 * purpose: C++ Template
 *         To be copied for each project
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries 

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Colum

//Function Prototypes 

//Execution Begins Here!

int main(int argc, char** argv) {
        //Declare Variables 
    
        //Initial Variables
    
        //Map/Process Inputs to Outputs
    
        //Display Outputs
        cout<<"Hello World"<<endl;
        //Exit program

    return 0;
}

