/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on May 17, 2018, 11:30 AM
 * Purpose:  BlackJack
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Random Numbers
#include <ctime>    //Time to set the seed
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns


//Function Prototypes
void filDeck(char [],char);
char suit(char);
char face(char);
void shuffle(char [],char);
void prtDck(char [], char, char);
void selSort(char [], char);
void deal(char [], char, char[], char);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Initialize the random number generator
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables
    const char DECKSZ=52;
    char deck[DECKSZ];
    const char HNDSZ=5;
    char hand[HNDSZ];
    //Initial Variables
    filDeck(deck, DECKSZ);
    shuffle(deck, DECKSZ);
    selSort(deck,DECKSZ);
    prtDck(deck, DECKSZ,13);
    for(int tryit=1;tryit<=11;tryit++){
    deal(deck, DECKSZ, hand, HNDSZ);
    prtDck(hand, HNDSZ,5);
    }
    prtDck(deck, DECKSZ,13);
    //Map/Process Inputs to Outputs
    //Output the results
    //Exit program!
    return 0;
}

void filDeck(char c[],char n){
    for(int eachCrd=0;eachCrd<n;eachCrd++){
        c[eachCrd]=eachCrd;
    }
}

char suit(char card){
    string suitVal="SCDH";
    return suitVal[card/13];
}
char face(char card){
    string faceVal="A23456789TJQK";
            return faceVal[card%13];
}
void shuffle(char c[],char nCard){
    for(int shfl=1;shfl<=7;shfl++){
        for(int card=0;card<nCard;card++){
            int random=rand()%nCard;
            char temp=c[card];
            c[card]=c[random];
            c[random]=temp;
        }
    }
}
void prtDck(char deck[], char nCard, char perLine){
    cout<<endl;
    for(int card=0;card<nCard;card++){
        cout<<face(deck[card])<<suit(deck[card])<<" ";
        if(card%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
}

void selSort(char deck[], char dckSize){
    for(int lstSize=0;lstSize<dckSize-1;lstSize++){
        char idxSml=lstSize;
        for(int findSml=lstSize+1;findSml<dckSize;findSml++){
            if(deck[idxSml]>deck[findSml]){
                idxSml=findSml;
            }
        }
        char temp=deck[lstSize];
        deck[lstSize]=deck[idxSml];
        deck[idxSml]=temp;
    }
}



void deal(char deck[], char nDckCrd, char hand[], char nHdCrds){
    static char current=0;
    if(current>nDckCrd*nHdCrds){
        shuffle(deck, nDckCrd);
        current=0;
    }
    for(int card=0;card<nHdCrds;card++){
        hand[card]=deck(deck,nHdCrds);
        current++;
    }
}