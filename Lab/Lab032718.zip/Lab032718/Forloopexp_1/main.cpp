/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on March 27, 2018, 10:00 AM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
#include <fstream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    ofstream out;
    //Input or initialize values Here
    out.open("Clock.out");  
 
    //Process/Calculations Here
    for(int hours1=0; hours1<=12; hours1++){
            for(int mins1=0; mins1<=5; mins1++){
                for(int mins2=0; mins2<=9; mins2++){
                    for(int sec1=0; sec1<=5; sec1++){
                        for(int sec2=0; sec2<=9; sec2++){
                            if(hours1<=9){
                            cout<<"0"<<hours1<<":"<<mins1<<mins2<<":"<<sec1<<sec2<<endl;
                            }else{
                            cout<<hours1<<":"<<mins1<<mins2<<":"<<sec1<<sec2<<endl;
                            }
                        }
                    } 
                }
            }     
        }
    //Output Located Here

    out.close();
    //Exit
    return 0;
}

