/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on May 31th, 2018, 10:30 AM
 * Purpose:  Specification for the 1-d Array Structure
 */

#ifndef ARRAY2D_H
#define ARRAY2D_H

struct Array2D{
    int row;   //# of rows
    int cols;  //#of columns
    int **data;//Size of the 1-D Array
};

#endif /* ARRAY1D_H */

