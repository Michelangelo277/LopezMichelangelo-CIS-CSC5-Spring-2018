/* 
 * File:   main.cpp
 * Author: Michelangelo, Lopez
 * Created on March 1, 2018, 12:00 AM
 * Purpose: Random number test with a comparision of interpolation to 
 * a first order polynomial 
 */

//System Libraries Here
#include <iostream>
#include <cstdlib> //random number generator
#include <ctime> //time to seed random generator
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //seed random number generator once, here only
    srand(static_cast<unsigned int>(time(0)));
    //Declare all Variables Here
    unsigned char  f1=32, f2=212, c1=0, c2=100;//table values for temperature 
    float m=5.0f/9.0f, b=-32.0f;//polynomial coefficients 
    float ceq, cint,f;//temperature values and conversions
    //Input or initialize values Here
    f=rand()%181+32;//Range between (32, 212)
    //Process/Calculations Here
    ceq=m*(f+b);
    cint=c1+static_cast<float>(c2-c1)/(f2-f1)*(f-f1);        
    //Output Located Here
    cout<<f<<" Fahrenheit ="<<ceq<<" Centigrade Equation = "<<cint<<
            " Celsius Interpolation "<<endl;
    //Exit
    return 0;
}

