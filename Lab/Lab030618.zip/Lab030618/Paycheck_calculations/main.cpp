/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    
    float payRate, hrsWrkd, ss, fedTax, statTax, unDues, numDep, grsPay, hlthIns, netPay;
    
    
    //Input or initialize values Here
    payRate=16.78f;
    ss=0.06f;
    fedTax=0.14f;
    statTax=0.05f;
    unDues=10.0f;
    hlthIns=35.0f;
    
    
    
    //Process/Calculations Here
    cout<<"input the hours worked "<<endl;
    cin>>hrsWrkd;
    grsPay=hrsWrkd*payRate;
    grsPay+=grsPay>40?(hrsWrkd-40)*payRate/2:0;
    ss*=grsPay;
    fedTax*=grsPay;
    statTax*=grsPay;
    cout<<"Input the number of dependents"<<endl;
    cin>>numDep;
    hlthIns=numDep>='3'?hlthIns:0;
    netPay=grsPay-ss-fedTax-statTax-unDues-hlthIns;

    //Output Located Here
    cout<<"Hours worked: "<<hrsWrkd<<" hours"<<endl;
    cout<<"Number of Dependents "<<numDep<<endl;
    cout<<"Percent of social security  "<<hrsWrkd<<endl;
    cout<<"Percent of Federal Tax: $ "<<fedTax<<endl;
    cout<<"Percent of State Tax: $ "<<statTax<<endl;
    cout<<"Health Insurance $ "<<hlthIns<<endl;
    cout<<"Union Dues $ "<<unDues<<endl;
    cout<<"Gross Pay $"<<grsPay<<endl;
    cout<<"Net Pay $"<<netPay<<endl;
    //Exit
    return 0;
}

