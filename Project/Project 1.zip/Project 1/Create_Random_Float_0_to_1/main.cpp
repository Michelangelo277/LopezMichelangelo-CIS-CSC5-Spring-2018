/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on April 3, 2018, 9:52 AM
 * Purpose: Create a random number between 1 and 0
 */

//System Libraries Here
#include <iostream>  //I/O -> cout,endl
#include <cstdlib>   //Srand/Rand
#include <ctime>     //Time
#include <iomanip>   //Format 
#include <cmath>     //Math Function
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
const unsigned int MAXRAND=pow(2,31)-1;
//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Initialize Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    //Declare all Variables Here
    int loop; 
    float minRnd, maxRnd;
    //Input or initialize values Here
    loop=1000000;
    maxRnd=minRnd=static_cast<float>(rand())/MAXRAND;
    //Process/Calculations Here
    for(int i=1;i<=loop;i++){
        float random=static_cast<float>(rand())/MAXRAND;
        if(maxRnd<random)maxRnd=random;
        if(minRnd>random)minRnd=random;
    
    }
    //Output Located Here
    cout<<fixed<<setprecision(5)<<showpoint;
    cout<<"Number of random function calls = "<<loop<<endl;
    cout<<"Minimum random number detected  = "<<minRnd<<endl;
    cout<<"Maximum random number detected  = "<<maxRnd<<endl;
    //cout<<"                        2^31-1 = "
            //<<setw(10)<<(pow(2,31)-1)<<endl;
    
    
             
    //Exit
    return 0;
}

