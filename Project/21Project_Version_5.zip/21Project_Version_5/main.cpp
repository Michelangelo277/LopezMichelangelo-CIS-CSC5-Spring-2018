/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on May 31, 2018, 11:00 PM
 * Purpose:  Blackjack Project 2 Version 5
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
#include <cstdlib>		//Rand function
#include <ctime>		//Time
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
void crtDeck (int[], int);
void filHand (int[], int);
int crdVal (char);
char filVal (char[], int);
string filSuit (string[], int);
//Program Execution Begins Here
int main (int argc, char **argv){
  //Set the Random Number Seed
  srand (static_cast < unsigned int >(time (0)));
  //Declare all Variables Here
  bool lossCon=true;
  char choice, choice2;
  const int CRDVAL = 13;
  const int SUITVAL = 4;
  char card[CRDVAL];
  string suit[SUITVAL];
  const int MXHNDSZ = 5;
  int plyrHnd[MXHNDSZ];		//Player's cards
  int plyrSut[SUITVAL];
  int dlrHnd[MXHNDSZ];		//Dealer's cards  
  int dlrSuit[SUITVAL];
  int credits = 100,		//Amount of Money(in dollars) is determined by user input
    twOne,                      //Win condition for the player
    twOne2,		        //win condition for the dealer
    ace,			//value to determine which value an ace can be
    cnt;
  int value = 0;
  char temp = ' ';
  cout << "Welcome to Blackjack!" << endl;
  cout << "Press any key to start" << endl;
  cin >> choice;
  if (choice != 'n' || choice != 'N'){
  cout << "Input the amount of money you want to start with" << endl;
          cin >> credits;
  }else{
      lossCon==false;
  }
  do{
      if (choice != 'n' || choice != 'N'){
          
          if(credits==0){
            lossCon==false;
          }
          for (int i = 0; i < 2; i++){
              temp = filVal (card, CRDVAL);
              filSuit (suit, SUITVAL);
              value = crdVal (temp);
              plyrSut[i] = temp;
              plyrHnd[i] = value;
              twOne = plyrHnd[0] + plyrHnd[1];         
              cout << "Player's hand" << endl << temp 
                      << filSuit (suit, SUITVAL) <<endl;
              cout << "The card's Value: " << value << endl;
              cout << "Total Value: " << twOne << endl;
              
            }
          cout<<endl;
          for (int i = 0; i < 2; i++){
              temp = filVal (card, CRDVAL);
              filSuit (suit, SUITVAL);
              value = crdVal (temp);
              dlrSuit[i] = temp;
              dlrHnd[i] = value;
              twOne2 = dlrHnd[0] + dlrHnd[1];
               cout << "Dealer's hand" << endl << temp 
                       << filSuit (suit, SUITVAL) <<endl;
              cout << "The card's Value: " << value << endl;
              cout << "Total Value: " << twOne << endl;
            }
        }

    if (twOne==21||twOne>twOne2&&twOne<21){//If the User's card value total is equal to 21 or is greater than the dealer's card value display if they won       
        credits += 100;		//add 100 to the user's credits
        cout << "\n You win! " << twOne << " " << twOne2 << " $" << credits <<
          endl;
    }
    else if (twOne > 21 || twOne2 > twOne) {
        //Else if the user's card total is greater than 21 or less than the dealer's display they've lost
        credits -= 100;		//subtract 100 from the user's credits
        cout << "Dealer wins " << twOne << " " << twOne2 << " $" << credits <<endl;
    }else if(twOne==twOne2){
        credits=credits;
        cout << "DRAW " << twOne << " " << twOne2 << " $" << credits <<endl;
    }
    


    //Output Located Here
    if (credits == 0||choice=='N'||choice=='n'){
        cout << "Game Over" << endl;
        lossCon=false;
    }else if(credits>0){
    cout << "Press any key to play again" << endl;   
    }
  cin>>choice;
  }while(lossCon==true);
    //Exit
    return 0;
}





string filSuit (string s[], int size){
  int temp;
  for (int i = 0; i < size; i++)
    {
      if (i == 0)
	{
	  s[i] = " of Spades";
	}
      if (i == 1)
	{
	  s[i] = " of Diamonds";
	}
      if (i == 2)
	{
	  s[i] = " of Hearts";
	}
      if (i == 3)
	{
	  s[i] = " of Clubs";
	}
    }
  temp = rand () % 4;
  s[temp];
  return s[temp];
}


char filVal (char c[], int sizeVal)
{
  int shuffle;
  for (int i = 0; i < sizeVal; i++)
    {
      if (i == 0)
	{
	  c[i] = 'A';
	}
      if (i == 1)
	{
	  c[i] = '2';
	}
      if (i == 2)
	{
	  c[i] = '3';
	}
      if (i == 3)
	{
	  c[i] = '4';
	}
      if (i == 4)
	{
	  c[i] = '5';
	}
      if (i == 5)
	{
	  c[i] = '6';
	}
      if (i == 6)
	{
	  c[i] = '7';
	}
      if (i == 7)
	{
	  c[i] = '8';
	}
      if (i == 8)
	{
	  c[i] = '9';
	}
      if (i == 10)
	{
	  c[i] = 'T';
	}
      if (i == 11)
	{
	  c[i] = 'J';
	}
      if (i == 12)
	{
	  c[i] = 'Q';
	}
      if (i == 13)
	{
	  c[i] = 'K';
	}
    }
  shuffle = rand () % 13;
  c[shuffle];
  return c[shuffle];
}


int crdVal (char val){
  int card = 0;
  if (val == 'A')
    {
      card = 1;
    }
  else if (val == '2')
    {
      card = 2;
    }
  else if (val == '3')
    {
      card = 3;
    }
  else if (val == '4')
    {
      card = 4;
    }
  else if (val == '5')
    {
      card = 5;
    }
  else if (val == '6')
    {
      card = 6;
    }
  else if (val == '7')
    {
      card = 7;
    }
  else if (val == '8')
    {
      card = 8;
    }
  else if (val == '9')
    {
      card = 9;
    }
  else if (val == 'T')
    {
      card = 10;
    }
  else if (val == 'J')
    {
      card = 10;
    }
  else if (val == 'Q')
    {
      card = 10;
    }
  else if (val == 'K')
    {
      card = 10;
    }
  return card;
}