
/* 
 * File:   main.cpp
 * Author: Lopez, Michelangelo
 * Created on March 4, 2018
 * purpose: Creating a Diamond out of Asterisks 
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries 

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Colum

//Function Prototypes 

//Execution Begins Here!

int main(int argc, char** argv) {
        //Declare Variables 

        //Initial Variables

        //Map/Process Inputs to Outputs
    
        //Display Outputs
        cout<<"   *"<<endl;
        cout<<"  ***"<<endl;
        cout<<" *****"<<endl;
        cout<<"*******"<<endl;
        cout<<" *****"<<endl;
        cout<<"  ***"<<endl;
        cout<<"   *"<<endl;
        //Exit program

    return 0;
}

