/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on March 22, 2018, 7;53 AM
 * Purpose: Menu with 9 problems from the gaddis book
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
const float GRAVITY=6.673e-8f;//cm^3/g/sec^2
const float CMMTRS=0.01f;//cm to meters
const float MTRSFT=3.281f;//Meters to Feet
const float LBSLUG=32.174f;//Pounds per slug
//Function Prototypes Here


//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    char choice;
    do{
    cout<<"Choose the project you want to view."<<endl;
    cout<<"type 1 for the first project"<<endl;
    cout<<"type 2 for the second project"<<endl;
    cout<<"type 3 for the third project"<<endl;       
    cout<<"type 4 for the forth project"<<endl;
    cout<<"type 5 for the fifth project"<<endl;
    cout<<"type 6 for the sixth project"<<endl;       
    cout<<"type 7 for the seventh project"<<endl;  
    cout<<"type 8 for the eighth project"<<endl;
    cout<<"type 9 for the ninth project"<<endl;       
 
    cin>>choice;
    //Input or initialize values Here
    
    if (choice>='1' && choice<='9'){
        switch(choice){
            case '1':{
            //Declare all Variables Here

            int month, numYrs, rnFll, totRain;
            //Input or initialize values Here
            cout<<"Input the number of years"<<endl;
            cin>>numYrs;
            //Process/Calculations Here
            for(int years=1;years<=numYrs;years++){
                month=numYrs*12;
                for(int months=1;months<=12;months++){
                    cout<<"Input the rainfall for month "<<months<<" of Year "<<years<<endl;
                    cin>>rnFll;
                    totRain+=rnFll;
                }
            }
            month=numYrs*12;
            //Output Located Here
            cout<<"The average rainfall is "<<totRain/month<<endl;            
                break;
            }
           
             case '2':{
             //Declare all Variables Here
             float myMass, msEarth, rEarth, myWt, myWtCnv;
             //Input or initialize values Here
             myMass=6;//Slugs*conversion
             myWtCnv=myMass*LBSLUG;
             msEarth=5.972e27f;//grams
             rEarth=6.371e6f;//Meters
             //Process/Calculations Here
             myWt=GRAVITY*CMMTRS*CMMTRS*CMMTRS*myMass*msEarth*MTRSFT/(rEarth*rEarth);
             //Output Located Here
             cout<<fixed<<setprecision(0);
             cout<<myMass<<" slugs = "<<myWt<<" lbs"<<endl;   
             cout<<myMass<<" slugs = "<<myWtCnv<<" lbs"<<endl;                                  
                break;
            }
              case '3':{
            //Declare all Variables Here
            int budget,expAmnt,cost,totExp;
            string expense;
            //Input or initialize values Here
            cout<<"Input your budget for the month"<<endl;
            cin>>budget;
            cout<<"Input the amount of expenses you have for the month"<<endl;
            cin>>expAmnt;
            //Process/Calculations Here
        for(int expns=1;expns<=expAmnt;expns++){
            cout<<"Input an expense"<<endl;        
            cin>>expense;
            cout<<"Input the amount you pay for this Expense"<<endl;
            cin>>cost;
            cout<<"Expense: "<<expense<<" Cost = $"<<cost<<endl;
            totExp+=cost;


        }
        //Output Located Here
        if(totExp>budget){
            cout<<"You are over budget"<<endl;
        }else if(totExp<budget){
            cout<<"You are under budget"<<endl; 
            }else{
                cout<<"You have no money"<<endl;
            }     
                break;
            }
               case '4':{
               //Declare all Variables Here
               int play, num;
               //Input or initialize values Here
               //Process/Calculations Here
    do{
        cout<<"Guess a number between 1-10"<<endl;
        cin>>play;
        num=rand()%10+1;
        if(num>play){
            cout<<"Number is too low. Try again."<<endl;
        }else if(num<play){
            cout<<"Number is too high"<<endl;
        }
        
    }while(num!=play);
    cout<<"You win! :D"<<endl;
                break;
            }
               case '5':{
               //Declare all Variables Here
               int play, num, plyCnt;
               //Input or initialize values Here

               //Process/Calculations Here
            do{
            cout<<"Guess a number between 1-10"<<endl;
            cin>>play;
            num=rand()%10+1;
            if(num>play){
                cout<<"Number is too low. Try again."<<endl;
            }else if(num<play){
                cout<<"Number is too high"<<endl;
            }
                plyCnt+=1;
            }while(num!=play);
                cout<<"You win! :D"<<endl;
                cout<<"Attempts: "<<plyCnt<<endl;
                break;
            }   
               case '6':{
               //Declare all Variables Here
               float seaLvl;
               //Input or initialize values Here
               seaLvl=0;      
               //Process/Calculations Here
                for(int years=1;years<=25;years++){
                    seaLvl+=1.5f;
                    cout<<"Sea Level in Year "<<years<<":   "<<seaLvl<<" Millimeters"<<endl;
               }
                
                break;
            }
               case '7':{
                //Declare all Variables Here
                float memFee=2500,//Dollars paid per year
                prIncr=0.04;//Percent Increase per year
                //Input or initialize values Here
    
                //Process/Calculations Here
                for(int years=1;years<=6;years++){
                    memFee=(memFee*prIncr)+memFee;
                    cout<<"Membership Price to Country Club in "<<years<<":   $"<<memFee<<endl;
                }
               
                break;
            }
               case '8':{
            //Declare all Variables Here
            int dstnce, timeTr, speed;
            //Input or initialize values Here
            cout<<"Input the speed of your vehicle in MPH."<<endl;
            cin>>speed;//Miles Per Hour
            cout<<"Input the time you traveled in hours."<<endl;
            cin>>timeTr;
            cout<<"Time Traveled        Speed of Vehicle      Distance Traveled"<<endl;
            cout<<"____________________________________________________________"<<endl;
            //Process/Calculations Here
                for(int time=1;time<=timeTr;time++){
                    dstnce=time*speed;
                    cout<<time<<" hours             "<<speed<<" "
                    "Miles Per Hour            "<<dstnce<<" Miles"<<endl;
                }
                break;
            }
               case '9':{
                 //Declare all Variables Here
                unsigned int totPay, pyPrDay;//Pennies of Pay
                char numDays=31;//Most number of days in a month
                //Input or initialize values Here

                pyPrDay=1;//Penny on first day
                totPay=pyPrDay;//Total Amount
                //Process/Calculations Here
                cout<<fixed<<setprecision(2)<<showpoint;
                cout<<"Day       Per           Total"<<endl;
                for(int day=1;day<=numDays;day++){
                    cout<<setw(2)<<day
                    <<setw(12)<<pyPrDay/100.0f
                    <<setw(14)<<totPay/100.0f<<endl;
                    pyPrDay*=2;
                    totPay+=pyPrDay;
                }
                
                break;
            }
        }
    }else{
        cout<<"Exiting menu"<<endl;
    }
    }while(choice!='n');
    //Process/Calculations Here

    //Output Located Here
  
    //Exit
    return 0;
}
 
