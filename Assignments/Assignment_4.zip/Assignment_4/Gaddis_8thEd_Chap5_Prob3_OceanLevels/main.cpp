/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on April 3, 2018
 * Purpose: To calculate the amount of millimeters the ocean level rose from 
 * its original level every year for 25 years
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
 
    //Declare all Variables Here
    float seaLvl;
    //Input or initialize values Here
    seaLvl=0;      
    //Process/Calculations Here
    for(int years=1;years<=25;years++){
        seaLvl+=1.5f;
        cout<<"Sea Level in Year "<<years<<":   "<<seaLvl<<" Millimeters"<<endl;
    }
    //Output Located Here
    
    //Exit
    return 0;
}

