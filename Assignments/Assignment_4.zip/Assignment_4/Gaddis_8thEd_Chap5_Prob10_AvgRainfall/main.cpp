/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on April 3, 2018
 * Purpose: To Calculate the Average rainfall over user input years
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
 
    //Declare all Variables Here

    int month, numYrs, rnFll, totRain;
    //Input or initialize values Here
    cout<<"Input the number of years"<<endl;
    cin>>numYrs;
    //Process/Calculations Here
    for(int years=1;years<=numYrs;years++){
        month=numYrs*12;
        for(int months=1;months<=12;months++){
            cout<<"Input the rainfall for month "<<months<<" of Year "<<years<<endl;
            cin>>rnFll;
            totRain+=rnFll;
        }
    }
    month=numYrs*12;
    //Output Located Here
            //mnthAvg+=rnFll/2;
            cout<<"The average rainfall is "<<totRain/month<<endl;
    //Exit
    return 0;
}

