/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on March 29, 2018, 12:03 AM
 * Purpose:  Attraction to the earth
 */

//System Libraries Here
#include <iostream>//io library
#include <iomanip>//format

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
const float GRAVITY=6.673e-8f;//cm^3/g/sec^2
const float CMMTRS=0.01f;//cm to meters
const float MTRSFT=3.281f;//Meters to Feet
const float LBSLUG=32.174f;//Pounds per slug
//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the random seed
    
    //Declare all Variables Here
    float myMass, msEarth, rEarth, myWt, myWtCnv;
    //Input or initialize values Here
    myMass=6;//Slugs*conversion
    myWtCnv=myMass*LBSLUG;
    msEarth=5.972e27f;//grams
    rEarth=6.371e6f;//Meters
    
    //Process/Calculations Here
    myWt=GRAVITY*CMMTRS*CMMTRS*CMMTRS*myMass*msEarth*MTRSFT/(rEarth*rEarth);
    //Output Located Here
    cout<<fixed<<setprecision(0);
    cout<<myMass<<" slugs = "<<myWt<<" lbs"<<endl;   
    cout<<myMass<<" slugs = "<<myWtCnv<<" lbs"<<endl;
    //Exit
    return 0;
}

