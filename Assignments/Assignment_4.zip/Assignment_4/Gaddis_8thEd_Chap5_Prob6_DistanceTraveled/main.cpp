/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on April 3, 2018
 * Purpose: To calculate the distance traveled for every hour of traveling
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
 
    //Declare all Variables Here
    int dstnce, timeTr, speed;
    //Input or initialize values Here
    cout<<"Input the speed of your vehicle in MPH."<<endl;
    cin>>speed;//Miles Per Hour
    cout<<"Input the time you traveled in hours."<<endl;
    cin>>timeTr;
    cout<<"Time Traveled        Speed of Vehicle      Distance Traveled"<<endl;
    cout<<"____________________________________________________________"<<endl;
    //Process/Calculations Here
    for(int time=1;time<=timeTr;time++){
        dstnce=time*speed;
        cout<<time<<" hours             "<<speed<<" "
                "Miles Per Hour            "<<dstnce<<" Miles"<<endl;
    }
    //Output Located Here
    
    //Exit
    return 0;
}

