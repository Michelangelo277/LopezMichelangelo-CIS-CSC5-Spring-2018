/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on April 3, 2018
 * Purpose: To Calculate the Average rainfall over user input years
 */

//System Libraries Here
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    //Declare all Variables Here
    int play, num;
    //Input or initialize values Here

    //Process/Calculations Here
    do{
        cout<<"Guess a number between 1-10"<<endl;
        cin>>play;
        num=rand()%10+1;
        if(num>play){
            cout<<"Number is too low. Try again."<<endl;
        }else if(num<play){
            cout<<"Number is too high"<<endl;
        }
        
    }while(num!=play);
    cout<<"You win! :D"<<endl;
    //Output Located Here

    //Exit
    return 0;
}

