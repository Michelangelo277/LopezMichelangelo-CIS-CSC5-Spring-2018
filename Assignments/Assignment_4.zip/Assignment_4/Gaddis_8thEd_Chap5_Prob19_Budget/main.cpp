/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on April 3, 2018
 * Purpose: To analyze a budget
 */

//System Libraries Here
#include <iostream>
#include <cstdlib>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
 
    //Declare all Variables Here
    int budget,expAmnt,cost,totExp;
    string expense;
    //Input or initialize values Here
    cout<<"Input your budget for the month"<<endl;
    cin>>budget;
    cout<<"Input the amount of expenses you have for the month"<<endl;
    cin>>expAmnt;
    //Process/Calculations Here
    for(int expns=1;expns<=expAmnt;expns++){
        cout<<"Input an expense"<<endl;        
        cin>>expense;
        cout<<"Input the amount you pay for this Expense"<<endl;
        cin>>cost;
        cout<<"Expense: "<<expense<<" Cost = $"<<cost<<endl;
        totExp+=cost;


    }
    //Output Located Here
    if(totExp>budget){
        cout<<"You are over budget"<<endl;
    }else if(totExp<budget){
        cout<<"You are under budget"<<endl; 
    }else{
        cout<<"You have no money"<<endl;
    }
    //Exit
    return 0;
}

