/* 
 * File:   main.cpp
 * Author: Michelangelo Lopez
 * Created on April 3, 2018
 * Purpose: To calculate the amount of millimeters the ocean level rose from 
 * its original level every year for 25 years
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
 
    //Declare all Variables Here
    float memFee=2500,//Dollars paid per year
          prIncr=0.04;//Percent Increase per year
    //Input or initialize values Here
    
    //Process/Calculations Here
    for(int years=1;years<=6;years++){
        memFee=(memFee*prIncr)+memFee;
        cout<<"Membership Price to Country Club in "<<years<<":   $"<<memFee<<endl;
    }
    //Output Located Here
    
    //Exit
    return 0;
}

